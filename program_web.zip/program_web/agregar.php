<?php
    session_start();
    if (@!$_SESSION['usuario']) {
        header("Location:index.php");
    }
?>

<!DOCTYPE html>
<html>
<head>
	<title>Agregar Paciente</title>
		<link rel="stylesheet" href="css/style2.css">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
</head>

<body style="background-color: rgb(243, 254, 244)">

<!--Imagen Asmedan al principio de pantalla-->
	<a href="inicio.php"><img align="right" src="img/lg_asm.png" width="15%" height="18%" style="float: left; position: absolute;"></a>

<br><br><br><br><br><br><br><br>

<form method="POST" action="inicio.php">

<p align="center">Debe ingresar primero el tipo de documento seguido del número. Ej: CC123456</p><br>

	<div class="form-item col-5">
	    <input class="formulario" name="cc" type="text" required="" minlength="4" autocomplete="off" id="name"/>
	    <label class="label" for="name">Identificación</label>
	</div>

	<div class="form-item col-5">
	    <input class="formulario" name="nombre" type="text" required="" minlength="15" autocomplete="off" style="text-transform: capitalize;" id="name"/>
	    <label class="label" for="name">Nombre</label>
	</div>

<br><br>
	<input class="bguardar" type="submit" name="guardarr" value="Guardar">
	<a href="inicio.php" style="background-color: #b3b3b3; border-radius: 10px; text-decoration: none; color: black; padding: 5px;">Cancelar</a>
</form>

<!--Tiempo de inactividad cierre de sesion-->
<div id="indicator" class="activ"></div>
<script type="text/javascript">
	var indicator = document.getElementById('indicator');
var sleepTimer;

document.addEventListener('mousemove', activityDetected);
document.addEventListener('keypress', activityDetected);

function setSleepTimer() {
  sleepTimer = setTimeout(dozeOff, 900000);//tiempo de inactividad para bloqueo 15 minutos
}

function resetSleepTimer() {
  clearTimeout(sleepTimer);
  setSleepTimer();
}

function activityDetected() {
  resetSleepTimer();
  wakeUp();
}

function dozeOff() {
	location.href="index.php";
}

setSleepTimer();
</script>

</body>
</html>

