<!DOCTYPE html>
<html>

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Tienda</title>

    <!-- CSS Bootstrap -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/full-slider.css" rel="stylesheet">

    <!--Diseño tarjetas-->
      <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Nunito+Sans:300,400,700'>
      <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Poppins:300,400,700'>
      <link rel="stylesheet" type="text/css" href="css/style.css">




  <!--Diseño menu-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <!--Diseño menu-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <link rel="stylesheet" href="admin/css/mee.css">
    <link rel="stylesheet" href="plugins/datepicker/datepicker3.css">

  </head>

  <body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
  <div class="container">
    <a class="navbar-brand" href="#">Tienda</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item active">
          <a class="nav-link" href="#">Inicio
            <span class="sr-only">(current)</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Tejedor</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Opción 1</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="index.php">Cerrar Sesion</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<header>

</header>

<!--Validación inicio de sesion-->
<?php
    $con=mysqli_connect("localhost","root","","tejedores")or die("error");
    session_start();

    session_start();
    if (@!$_SESSION['usuario']) {
        header("Location:index.php");
    }
    elseif (@!$_SESSION['usuario']) {
        header("Location: inicio.php");
    }
    elseif ($_SESSION['rol']=='administrador') {
        header("Location: admin/admin.php");
    }
    elseif ($_SESSION['rol']=='consultas'){
      header("Location: admin/informe.php");
    }
?>


<!-- Page Content -->
<section class="py-5">
  <div class="container">
    <br>
  <!--Imprimir todo el nombre del usuario-->
    <div style="text-transform: capitalize;float: right;">
      <?php
        include("usuario2.php");
      ?>
    </div>
    <br>

  <!--Imprimir la hora y fecha-->
    <div style="float: right;">
      <?php
        include("hora/tiempo.php");
      ?>
    </div>
<br>

    <h1>.</h1>
    <p>.
      <code>.</code>
       .</p>
  </div>
</section>



<!--Agregar producto-->
<h1>Cargar y Almacenar imagen</h1>

      <form name="MiForm" id="MiForm" method="post" action="inicio.php" enctype="multipart/form-data">
        <div>
          <label>Archivos</label>
          <div>
            <input type="file" class="form-control" id="image" name="image" multiple>
          </div>
          <button name="submit" class="btn btn-primary">Cargar Imagen</button>
        </div>
      </form>

<img src='ver_producto.php?id=19' alt='producto' width="600" />      


<?php
if(isset($_POST["submit"])){
    $revisar = getimagesize($_FILES["image"]["tmp_name"]);
    if($revisar !== false){
        $image = $_FILES['image']['tmp_name'];
        $imgContenido = addslashes(file_get_contents($image));
        
        //Nombre de usuario
        $user=$_SESSION['usuario']; 

        //Credenciales BD
        $Host = 'localhost';
        $Username = 'root';
        $Password = '';
        $dbName = 'tejedores';
        
        //Crear conexion con la abse de datos
        $db = new mysqli($Host, $Username, $Password, $dbName);
        
        // Validar la conexion
        if($db->connect_error){
            die("Connection failed: " . $db->connect_error);
        }
        
        
        //Insertar imagen en la base de datos
        $insertar = $db->query("INSERT into productos (producto, fecha_carga,usuario) VALUES ('$imgContenido', now(),'$user')");
                // Condicional para verificar la subida del fichero'
        if($insertar){
        ?>
            <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
            <script type="text/javascript">
              swal("Acción exitosa", " ", "success");
            </script>
        <?php             
        }else{
        ?>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script type="text/javascript">
          sweetAlert ( "Ha fallado la subida, reintente nuevamente" , " " , "error" );
        </script>
    <?php         
        } 
    // Si el usuario no selecciona ninguna imagen
    }else{
        ?>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script type="text/javascript">
          sweetAlert ( "Por favor seleccione una imagen a subir" , " " , "error" );
        </script>
    <?php          
    }
}
?>






<!--Tarjetas-->
<div class="content">
  <p class="description"></p><a class="card" href="http://caracol.com.co/radio/2016/08/01/ecologia/1470072990_056861.html" target="_blank">

    <!--Primera tarjeta-->
    <div class="front">
      <p>La Vieja, más apetecida</p><br>

    </div>
    <img src='ver_producto.php?id=19' alt='producto' style="overflow: hidden;" />      

    <div class="back">
      <div>
        <p>La Vieja, más asas</p>
        <button class="button">Ir</button>
      </div>

    <!--Segunda tarjeta-->
    </div></a><a class="card" href="http://biodiversidadyconservacion.blogspot.com/2013/07/cerros-al-oriente-de-bogota.html" target="_blank">
    <div class="front">
      <p>Biodiversidad y Conservación</p>  
    </div>
    
  <img src='ver_producto.php?id=20' alt='producto' style="overflow: hidden;" />    

    <div class="back">
      <div>
        <p>Biodiversidad y Conservación</p>
        <button class="button">Ir</button>
      </div>

    <!--Tercera tarjeta-->
    </div></a><a class="card" href="https://sostenibilidad.semana.com/medio-ambiente/articulo/dos-nuevas-especies-de-insectos-fueron-registradas-en-la-quebrada-la-vieja/41863" target="_blank">

    <div class="front">
      <p>Dos nuevas especies de insectos fueron registradas en la Quebrada La Vieja</p>
    </div>
    <div class="back">
      <div>
        <p>Dos nuevas especies de insectos fueron registradas en la Quebrada La Vieja</p>
        <button class="button">Ir</button>
      </div>

    <!--Cuarta tarjeta-->
    </div></a><a class="card" href="http://caracol.com.co/emisora/2018/08/31/bogota/1535691263_334106.html" target="_blank">
    <div class="front">
      <p>Después de un año reabren el sendero ecológico La Vieja</p>
    </div>
    <div class="back">
      <div>
        <p>Después de un año reabren el sendero ecológico La Vieja</p>
        <button class="button">Ir</button>
      </div>

    <!--Quinta tarjeta-->
    </div></a><a class="card" href="http://www.bogota.gov.co/article/localidades/chapinero/disfrute%20de%20la%20caminata%20ecologica%20en%20chapinero" target="_blank">

    <div class="front">
      <p>Disfrute de la caminata ecológica en Chapinero</p>
    </div>

    <div class="back">
      <div>
        <p>Disfrute de la caminata ecológica en Chapinero</p>
        <button class="button">Ir</button>
      </div>

    <!--Sexta tarjeta-->
    </div></a><a class="card" href="https://www.car.gov.co/saladeprensa/se-autoriza-reapertura-de-la-quebrada-la-vieja-en-periodo-de-prueba" target="_blank">

    <div class="front" style="background-image: url(//source.unsplash.com/300x406);">
      <p>Se autoriza reapertura de la “quebrada La Vieja”, en periodo de prueba</p>
    </div>

    <div class="back">
      <div>
        <p>Se autoriza reapertura de la “quebrada La Vieja”, en periodo de prueba</p>
        <button class="button">Ir</button>
      </div>
    </div></a>

</div>






<!--Tabla-->
<div class="container">
    <div>
      <div>
  <!--Boton agregar -->
  <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" style="float: right;">Agregar usuario</button>
  <br><br><br>

          <table class="table table-bordered myTable" style="text-align: center;">
            <tr class="text-center">
              <th style="text-align: center;">ID</th>
              <th style="text-align: center;">Producto</th>
              <th style="text-align: center;">Título</th>
              <th style="text-align: center;">Descripción</th>
              <th style="text-align: center;">Fecha de Carga</th>
              <th style="text-align: center;">Usuario</th>
              <th style="text-align: center;">Acción</th>                                   
            </tr>
                <?php
                    $consulta="SELECT*FROM productos";
                    $ejecutar=mysqli_query($con,$consulta);
                    $i=0;
                    while($fila=mysqli_fetch_array($ejecutar)){
                      $id=$fila['id'];
                      $producto=$fila['producto'];
                      $titulo=$fila['titulo'];
                      $descripcion=$fila['descripcion'];
                      $fecha_carga=$fila['fecha_carga'];
                      $usuario=$fila['usuario'];
                      $i++;
                  ?>
            <tr>
              <td><?php echo $id; ?></td>
              <td><?php echo '<img height="80" width="80" src="data:image/jpeg;base64,'.base64_encode($fila["producto"]).'"/>';?></td>
              <td style="text-transform: capitalize;"><?php echo $titulo; ?></td>
              <td style="text-transform: capitalize;"><?php echo $descripcion; ?></td>
              <td><?php echo $fecha_carga; ?></td>
              <td><?php echo $usuario; ?></td>
              <td>
                <a href="admin.php?editar=<?php echo $usuario;?>"><input class="btn btn-warning" data-toggle="modal" type="submit" name="beditar" value="Editar o eliminar"></a>
              </td>
            </tr>
              <?php } ?>
          </table>
      

        </div>
      </div>
    </div>











<!--Tabla 2222-->
   <div class="table-responsive"  style="overflow-x: hidden;">

    <!--Excel-->
    <input type="button" class="btn btn-primary" id="btnExport" value="Exportar a Excel" style="float: right;">

    <br><br>
    <div class="row">
     <div class="input-daterange">
      <div class="col-md-4">
       <input type="text" name="start_date" id="start_date" class="form-control" placeholder="Desde la Fecha" autocomplete="off">
      </div>
      <div class="col-md-4">
       <input type="text" name="end_date" id="end_date" class="form-control" placeholder="Hasta la Fecha" autocomplete="off">
      </div>      
     </div>
     <div class="col-md-4">
      <input type="button" name="search" id="search" value="Buscar" class="btn btn-info active">
     </div>
    </div>
    <br><br><br>

<!--Excel-->
<div id="excel">
    <table id="order_data" class="table  table-striped  table-hover" style="zoom: 85%;">
     <thead>
        <tr>
            <th style="text-align: center;">ID</th>
            <th style="text-align: center;">Producto</th>
            <th style="text-align: center;">Título</th>
            <th style="text-align: center;">Descripción</th>
            <th style="text-align: center;">Fecha de Carga</th>
            <th style="text-align: center;">Usuario</th>
            <th style="text-align: center;">Acción</th>                                       
        </tr>
                <?php
                    $consulta="SELECT*FROM productos";
                    $ejecutar=mysqli_query($con,$consulta);
                    $i=0;
                    while($fila=mysqli_fetch_array($ejecutar)){
                      $id=$fila['id'];
                      $producto=$fila['producto'];
                      $titulo=$fila['titulo'];
                      $descripcion=$fila['descripcion'];
                      $fecha_carga=$fila['fecha_carga'];
                      $usuario=$fila['usuario'];
                      $i++;
                  ?>
            <tr>
              <td><?php echo $id; ?></td>
              <td><?php echo '<img height="80" width="80" src="data:image/jpeg;base64,'.base64_encode($fila["producto"]).'"/>';?></td>
              <td style="text-transform: capitalize;"><?php echo $titulo; ?></td>
              <td style="text-transform: capitalize;"><?php echo $descripcion; ?></td>
              <td><?php echo $fecha_carga; ?></td>
              <td><?php echo $usuario; ?></td>
              <td>
                <a href="admin.php?editar=<?php echo $usuario;?>"><input class="btn btn-warning" data-toggle="modal" type="submit" name="beditar" value="Editar o eliminar"></a>
              </td>
            </tr><?php } ?>
     </thead>
    </table>
    </div>
  </div>
  

<script type="text/javascript" language="javascript" >

$(document).ready(function(){

 $('.input-daterange').datepicker({
    "locale": {
        "separator": " - ",
        "applyLabel": "Aplicar",
        "cancelLabel": "Cancelar",
        "fromLabel": "Desde",
        "toLabel": "Hasta",
        "customRangeLabel": "Custom",
        "daysOfWeek": [
            "Do",
            "Lu",
            "Ma",
            "Mi",
            "Ju",
            "Vi",
            "Sa"
        ],
        "monthNames": [
            "Enero",
            "Febrero",
            "Marzo",
            "Abril",
            "Mayo",
            "Junio",
            "Julio",
            "Agosto",
            "Septiembre",
            "Octubre",
            "Noviembre",
            "Diciembre"
        ],
        "firstDay": 1
    },
  
  format: "dd/mm/yyyy",
  autoclose: true

 });

 fetch_data('no');

 function fetch_data(is_date_search, start_date='', end_date='')
 {
  var dataTable = $('#order_data').DataTable({

    "language":{
       "lengthMenu":"Mostrar _MENU_ registros por página.",
       "zeroRecords": "",
             "info": "",
             "infoEmpty": "",
             "infoFiltered": "",
             "search" : "Búsqueda",
             "LoadingRecords": "",
             " ": "",
             "SearchPlaceholder": "",
             "paginate": {
     "previous": "Anterior",
     "next": "Siguiente", 
     }
      },

   " " : true,
   "serverSide" : true,
   "sort": false,
   "order" : [],
   "ajax" : {
    url:"tabla.php",
    type:"POST",
    data:{
     is_date_search:is_date_search, start_date:start_date, end_date:end_date
    }
   }
  });
 }

 $('#search').click(function(){
  var start_date = $('#start_date').val();
  var end_date = $('#end_date').val();
  if(start_date != '' && end_date !='')
  {
   $('#order_data').DataTable().destroy();
   fetch_data('yes', start_date, end_date);
  }
 }); 
 
});
</script>




<script>
$("#btnExport").click(function(e) {
    window.open('data:application/vnd.ms-excel,' + encodeURIComponent($('#excel').html()));
    e.preventDefault();
});
</script>






    <!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; 2021</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- JavaScript Bootstrap -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="hora/tiempo.js"></script>

    <!--Función Tabla de productos-->
    <script src="bootstrap-3.3.7/js/jQuery-2.1.4.min.js"></script>
    <script src="bootstrap-3.3.7/js/bootstrap.min.js"></script>
    <script src="plugins/datepicker/bootstrap-datepicker.js"></script>
    <script src="plugins/datatables/jquery.js" type="text/javascript"></script>
    <script src="plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>


<!--Bloquear F12-->
<script type="text/javascript">
  $(document).keydown(function (event) {
    if (event.keyCode == 123) {
        return false;
    } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) {     
        return false;
    }
});
  $(document).on("contextmenu", function (e) {        
    e.preventDefault();
});
</script>


  </body>

</html>
