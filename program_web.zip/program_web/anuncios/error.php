<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<script type="text/javascript">
		sweetAlert ( "Usuario o contraseña incorrectos" , " " , "error" ).then(function(){window.location = "login.php";});
	</script>

</body>
</html>