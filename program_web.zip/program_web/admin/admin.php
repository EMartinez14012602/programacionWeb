<?php
  $con=mysqli_connect("localhost","id16807202_root","Nqwa8z\W0jee5UG@","id16807202_tejedores")or die("error");
  session_start();

  if (@!$_SESSION['usuario']) {
    header("Location: ../index.php");
  }
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Administrador</title>
  <!--Funcionamiento reloj-->
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <script  src="../hora/tiempo.js"></script>
    <link rel="stylesheet" href="../css/style2.css">
  <!--Diseño header-->
    <link rel="stylesheet" type="text/css" href="../css/dess.css">
  <!--Icono de cerrar sesion-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!--Diseño menu-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <link rel="stylesheet" href="css/mee.css">
</head>

<body ng-app="myApp" ng-controller="myController" style="background-color: rgb(243, 254, 244);">


<!--header-->
<div class="header">

  <!--Imagen  al principio de pantalla-->
    <a href="admin.php"><img align="right" src="../img/lg_asm.png" width="15%" height="18%" style="float: left; position: absolute;"></a>
      <!--Imprimir todo el nombre del usuario-->
    <div style="text-transform: capitalize;float: right;">
      <?php
        include("../usuario2.php");
      ?>
    </div>
<br>
  <!--Imprimir la hora y fecha-->
    <div style="float: right;">
      <?php
        include("../hora/tiempo.php");
      ?>
    </div>

<br><br><br>

<!--menu-->
<ul id="menu">

<!--  <li>
  	<a href="" class="es">Administrar médicos</a>
      <ul>
        <li>
        	<a class="ull" href="espec.php">Administrar especialidad</a>
        </li>
        <li>
        	<a class="ull2" href="doctor.php">Administrar doctores</a>
        </li>
      </ul>
  </li>

  <li><a href="cups.php">Administrar cups</a></li>
  <li><a href="paci.php">Administrar pacientes</a></li>
  <li><a href="consulta.php">Informe</a>
      <ul>
        <li>
        	<a style="margin-left: 500%;" href="devoluciones.php">Devoluciones</a>
        </li>
      </ul>
  </li>-->
  <li>
  	<a href=""><span class="glyphicon glyphicon-user"></span><?php include("../usuario3.php"); ?></a>
      <ul>
        <li>
        	<a href="../cambio.php?cambio=<?php echo $_SESSION['usuario']; ?>">Cambiar contraseña</a>
        </li>
      </ul>
  </li>
  <li><a href="../"><span class="glyphicon glyphicon-log-out"> Cerrar Sesión</span></a></li>
</ul>
<!--fin menu-->

<br><br><br><br><br><br>

    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <hr/>
            <p style="font-size: 23px;" class="text-center">Administrar usuarios</p>
          <hr/>
        </div>
      </div>
    </div>

<!--Guardar usuario-->
<?php
if(isset($_POST['agregar'])){
  $usuario1=$_POST['usuario'];
  $password1=$_POST['password'];
  $nombre_uno1=$_POST['nombre_uno'];
  $nombre_dos1=$_POST['nombre_dos'];
  $apellido_uno1=$_POST['apellido_uno'];
  $apellido_dos1=$_POST['apellido_dos'];
  $ciudad1=$_POST['ciudad'];
  $rol1=$_POST['rol'];

  $insertar="INSERT INTO usuarios (usuario,password,nombre_uno,nombre_dos,apellido_uno,apellido_dos,ciudad,rol)VALUES('$usuario1','$password1','$nombre_uno1','$nombre_dos1','$apellido_uno1', '$apellido_dos1','$ciudad1', '$rol1')";
  $ejecutar=mysqli_query($con,$insertar);

  $sql2="SELECT*FROM usuarios WHERE usuario='$usuario1'";
  $result2=mysqli_query($con,$sql2);
  $contar1=mysqli_num_rows($result2);
  
  if($ejecutar){
    ?>
      <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
      <script type="text/javascript">
        swal("Acción exitosa", " ", "success");
      </script>
    <?php
  }
  else if($contar1==1){
    ?>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script type="text/javascript">
          sweetAlert ( "El usuario ya existe" , " " , "error" );
        </script>
    <?php
  }
}
?>

<!-- Modal Agregar-->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
<!-- Modal Agregar-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h3 class="modal-title" align="center" >Agregar</h3>
        </div>
        <div class="modal-body">

<!--Agregar usuario-->
    <form method="POST" action="admin.php">
        <b>Usuario</b> 
            <input type="text" class="forml" name="usuario" required="" minlength="3" autocomplete="off" autofocus=""><br>
        <b>Contraseña</b> 
            <input type="password" class="forml" name="password" required="" minlength="4" autocomplete="off"><br>
        <b>Nombre uno</b> 
            <input type="text" class="forml" name="nombre_uno" required="" minlength="3" autocomplete="off" style="text-transform: capitalize;"><br>
        <b>Nombre dos</b> 
            <input type="text" class="forml" name="nombre_dos" minlength="3" autocomplete="off" style="text-transform: capitalize;"><br>
        <b>Apellido uno</b> 
            <input type="text" class="forml" name="apellido_uno" required="" minlength="3" autocomplete="off" style="text-transform: capitalize;"><br>
        <b>Apellido dos</b> 
            <input type="text" class="forml" name="apellido_dos" minlength="3" autocomplete="off" style="text-transform: capitalize;"><br>
        <b>Ciudad</b> 
            <input type="text" class="forml" name="ciudad" required="" minlength="4" autocomplete="off" style="text-transform: capitalize;"><br>
        <b>Permisos</b> <br>
        <label>
            <input type="radio" name="rol"  value="administrador" required="">Administrador
        </label>
        <br>
        <label>
            <input type="radio" name="rol" value="consultas">Consulta
        </label>          
        <br>
        <label>
            <input type="radio" name="rol" value="usuario">Usuario
        </label>      
        <br><br>
        <input type="submit" value="Añadir" name="agregar" class="btn btn-success btn-primary">
    </form>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
        </div>
      </div>
    </div>
  </div>
</div>

<!--Tabla-->
<div class="container">
    <div>
      <div>
  <!--Boton agregar -->
  <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" style="float: right;">Agregar usuario</button>
  <br><br><br>

          <table class="table table-bordered myTable" style="text-align: center;">
            <tr class="text-center">
              <th style="text-align: center;">Usuario</th>
              <th style="text-align: center;">Nombre</th>
              <th style="text-align: center;">ciudad</th>
              <th style="text-align: center;">Permiso</th>
              <th style="text-align: center;">Acciones</th>
            </tr>
                <?php
                    $consulta="SELECT*FROM usuarios";
                    $ejecutar=mysqli_query($con,$consulta);
                    $i=0;
                    while($fila=mysqli_fetch_array($ejecutar)){
                      $usuario=$fila['usuario'];
                      $nombre_uno=$fila['nombre_uno'];
                      $nombre_dos=$fila['nombre_dos'];
                      $apellido_uno=$fila['apellido_uno'];
                      $apellido_dos=$fila['apellido_dos'];
                      $ciudad=$fila['ciudad'];
                      $rol=$fila['rol'];
                      $i++;
                  ?>
            <tr>
              <td><?php echo $usuario; ?></td>
              <td style="text-transform: capitalize;"><?php echo $nombre_uno," ",$nombre_dos," ",$apellido_uno," ",$apellido_dos; ?></td>
              <td style="text-transform: capitalize;"><?php echo $ciudad; ?></td>
              <td style="text-transform: capitalize;"><?php echo $rol; ?></td>
              <td>
                <a href="admin.php?editar=<?php echo $usuario;?>"><input class="btn btn-warning" data-toggle="modal" type="submit" name="beditar" value="Editar o eliminar"></a>
              </td>
            </tr>
              <?php } ?>
          </table>

        </div>
      </div>
    </div>


<?php
  if(isset($_GET['editar'])){
    include("editar.php");
  }
?>

<!-- Modal Eliminar-->
  <div class="modal fade" id="eliminar" role="dialog">
    <div class="modal-dialog">
<!-- Modal Eliminar-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4>Eliminar</h4>
        </div>
        <div class="modal-body">

<!--Eliminar paciente-->
      <label style="font-size: 22px;">¿Está seguro de eliminar a <strong style="color: red;"><?php echo $usuario; ?></strong> ?</label>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
          <a href="admin.php?borrar=<?php echo $usuario; ?>"><input class="btn btn-danger" data-toggle="modal" ng-click="selectUser(user)" type="submit" name="beditar" value="Eliminar"></a>
        </div>
      </div>
    </div>
  </div>

<br><br><br>

<!--Eliminar usuario-->
<?php
  if(isset($_GET['borrar'])){
    $borrar_usuario=$_GET['borrar'];

    $borrar="DELETE FROM usuarios WHERE usuario='$borrar_usuario'";
    $ejecutar=mysqli_query($con,$borrar);

    if($ejecutar){
      ?>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script type="text/javascript">
      swal("Acción exitosa", " ", "success").then(function() {
    window.location = "admin.php";
});
    </script>
      <?php
    }
  }
?>
<!--
<script src='https://code.jquery.com/jquery-2.2.4.min.js'></script>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.5.5/angular.min.js'></script>
-->

<!--Bloquear F12-->
<script type="text/javascript">
	$(document).keydown(function (event) {
    if (event.keyCode == 123) {
        return false;
    } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) {     
        return false;
    }
});
	$(document).on("contextmenu", function (e) {        
    e.preventDefault();
});
</script>

<!--Tiempo de inactividad cierre de sesion-->
<div id="indicator" class="activ"></div>
<script type="text/javascript">
	var indicator = document.getElementById('indicator');
var sleepTimer;

document.addEventListener('mousemove', activityDetected);
document.addEventListener('keypress', activityDetected);

function setSleepTimer() {
  sleepTimer = setTimeout(dozeOff, 600000);//tiempo de inactividad para bloqueo 10 minutos
}

function resetSleepTimer() {
  clearTimeout(sleepTimer);
  setSleepTimer();
}

function activityDetected() {
  resetSleepTimer();
  wakeUp();
}

function dozeOff() {
	location.href="../index.php";
}

setSleepTimer();
</script>

</body>
</html>
