<?php
  $con=mysqli_connect("localhost","root","","bd_asmedan")or die("error");

/*Editar doctor*/
if(isset($_GET['editar_doctor'])){
    $editar_medic=$_GET['editar_doctor'];

    $consulta="SELECT*FROM medico WHERE cedula='$editar_medic'";
    $ejecutar=mysqli_query($con,$consulta);

    $fila=mysqli_fetch_array($ejecutar);

    $cedula=$fila['cedula'];
    $primer_nombre=$fila['primer_nombre'];
    $segundo_nombre=$fila['segundo_nombre'];
    $primer_apellido=$fila['primer_apellido'];
    $segundo_apellido=$fila['segundo_apellido'];
    $especialidad=$fila['especialidad'];
}
?>

<!--Actualizar datos usuario-->
<?php
  if(isset($_POST['actualizar'])){
    $actualizar_cedula=$_POST['cedula'];
    $actualizar_pn=$_POST['primer_nombre'];
    $actualizar_sn=$_POST['segundo_nombre'];
    $actualizar_pa=$_POST['primer_apellido'];
    $actualizar_sa=$_POST['segundo_apellido'];
    $actualizar_especialidad=$_POST['especialidad'];

    $actualizar="UPDATE medico SET cedula='$actualizar_cedula', primer_nombre='$actualizar_pn', segundo_nombre='$actualizar_sn', primer_apellido='$actualizar_pa', segundo_apellido='$actualizar_sa', especialidad='$actualizar_especialidad' WHERE cedula='$editar_medic'";

    $ejecutar=mysqli_query($con, $actualizar);

$sql2="SELECT*FROM medico WHERE cedula='$cedula'";
    $result2=mysqli_query($con,$sql2);
    $contar=mysqli_num_rows($result2);

    if($ejecutar){
        ?>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script type="text/javascript">
      swal("Acción exitosa", " ", "success").then(function() {
    window.location = "admin.php";
});
    </script>
        <?php
    }
else if($contar==1){
        ?>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script type="text/javascript">
        sweetAlert ( "El doctor ya existe"," ","error" );
    </script>
        <?php
    }
}
?>

<style type="text/css">
    body {
   overflow-x: hidden;
}
</style>

<br><br><br>

<!--Editar doctor-->
<form method="POST" action="" >
    <b>Cédula</b>
    <input name="cedula" class="feditar" type="number" value="<?php echo $cedula; ?>" required="" minlength="4" autocomplete="off"/><br><br><br>

    <b>Primer Nombre</b>
    <input name="primer_nombre" class="feditar" style="text-transform: capitalize;" type="text" value="<?php echo $primer_nombre; ?>" required="" minlength="3" autocomplete="off"/><br><br><br>   
    
    <b>Segundo Nombre</b>
    <input name="segundo_nombre" class="feditar" style="text-transform: capitalize;" type="text" value="<?php echo $segundo_nombre; ?>" minlength="3" autocomplete="off"/><br><br><br>

    <b>Primer Apellido</b>
    <input name="primer_apellido" class="feditar" style="text-transform: capitalize;" type="text" value="<?php echo $primer_apellido; ?>" required="" minlength="3" autocomplete="off"/><br><br><br>    

    <b>Segundo Apellido</b>
    <input name="segundo_apellido" class="feditar" style="text-transform: capitalize;" type="text" value="<?php echo $segundo_apellido; ?>" minlength="3" autocomplete="off"/><br><br><br>       

    <b>Especialidad</b>
<div class="container row">
    <div class="row" style="margin-left: 6%;">
            <select class="selectpicker show-menu-arrow" data-style="form-control" data-live-search="true" title="Elija la especialidad" name="especialidad">
                    <?php
                        $consulta="SELECT*FROM especialidad";
                        $ejecutar=mysqli_query($con,$consulta);
                        $i=0;

                        while($fila=mysqli_fetch_array($ejecutar)){
                            echo $especialidad=$fila['especialidad'];
                            $i++;
                    ?>
                <option value="<?php echo $especialidad; ?>" style="text-transform: capitalize;"><?php echo $especialidad; ?></option>
                    <?php } ?>
            </select>
        </div>
</div>
<br><br>
	<input type="submit" value="Editar" name="actualizar" class="btn btn-success btn-primary">
	<br>
<!--volver-->
<a href="javascript:history.go(-1);" style="background-color: #b3b3b3; border-radius: 10px; text-decoration: none; color: black; padding: 5px;">Cancelar</a>

</form>

<br><br><br><br>