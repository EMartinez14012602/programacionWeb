<?php
  $con=mysqli_connect("localhost","root","","bd_asmedan")or die("error");

	session_start();
	if (@!$_SESSION['usuario']) {
		header("Location: ../");
	}
?>

<!DOCTYPE html>
<html>

<head>
	    <meta charset="UTF-8">
	    <title>Administrar doctores</title>
	    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<!--Funcionamiento reloj-->
	    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
	    <script  src="../hora/tiempo.js"></script>
	    <link rel="stylesheet" href="../css/style2.css">
	<!--Diseño header-->
	    <link rel="stylesheet" type="text/css" href="../css/dess.css">
	<!--Icono de cerrar sesion-->
	    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<!--Diseño menu-->
	    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
	    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
	    <link rel="stylesheet" href="css/mee.css">
	<!--Diseño de la lupa-->
		<script src="https://use.fontawesome.com/a6d9678e21.js"></script>
	<!--Diseño buscador-->
	    <link rel="stylesheet" href="css/styles.css">
	<!--Diseño buscador de especialidad-->
		<link rel="stylesheet" type="text/css" href="../plugins/librerias/bootstrapp-select.min.css">
</head>

<script src='https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js'></script>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>
<script src="../plugins/librerias/bootstrap-select.min.js"></script>
<body style="background-color: rgb(243, 254, 244);">

<!--header-->
<div class="header">

  <!--Imagen Asmedan al principio de pantalla-->
    <a href="admin.php"><img align="right" src="../img/lg_asm.png" width="15%" height="18%" style="float: left; position: absolute;"></a>
      <!--Imprimir todo el nombre del usuario-->
    <div style="text-transform: capitalize;float: right;">
      <?php
        include("../usuario2.php");
      ?>
    </div>
<br>
  <!--Imprimir la hora y fecha-->
    <div style="float: right;">
      <?php
        include("../hora/tiempo.php");
      ?>
    </div>
    
<br><br><br>

<!--menu-->
<ul id="menu">

  <li>
  	<a href="" class="es">Administrar médicos</a>
      <ul>
        <li>
        	<a class="ull" href="espec.php">Administrar especialidad</a>
        </li>
      </ul>
  </li>

  <li><a href="cups.php">Administrar cups</a></li>
  <li><a href="paci.php">Administrar pacientes</a></li>
  <li><a href="consulta.php">Informe</a>
      <ul>
        <li>
        	<a style="margin-left: 500%;" href="devoluciones.php">Devoluciones</a>
        </li>
      </ul>
  </li>
  <li>
  	<a href="admin.php"><span class="glyphicon glyphicon-user"></span><?php include("../usuario3.php"); ?></a>
      <ul>
        <li>
        	<a href="../cambio.php?cambio=<?php echo $_SESSION['usuario']; ?>">Cambiar contraseña</a>
        </li>
      </ul>
  </li>

  <li><a href="../index.php"><span class="glyphicon glyphicon-log-out"> Cerrar Sesión</span></a></li>
</ul>
<!--fin menu-->

<br><br><br><br>

<!-- Modal Agregar-->
  <div class="modal fade" id="agregar" role="dialog">
    <div class="modal-dialog">
    
<!-- Modal Agregar-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <label class="modal-title" align="center" style="font-size: 20px; margin-left: 35%;">Agregar médico</label>
        </div>
        <div class="modal-body">

<!--Agregar paciente-->
<form method="POST" action="">
    <b>Cédula</b><br>
        <input type="number" class="fcups" name="cedula" minlength="5" autofocus="on" autocomplete="off" style="width: 300px;"><br>
    <b>Primer Nombre</b><br>
    <input type="text" class="fcups" name="primer_nombre" minlength="3" autocomplete="off" style="width: 300px; text-transform: capitalize;"><br>
    <b>Segundo Nombre</b><br>
    <input type="text" class="fcups" name="segundo_nombre" minlength="3" autocomplete="off" style="width: 300px; text-transform: capitalize;"><br>
    <b>Primer Apellido</b><br>
    <input type="text" class="fcups" name="primer_apellido" required="" minlength="3" autocomplete="off" style="width: 300px; text-transform: capitalize;"><br>
    <b>Segundo Apellido</b><br>
    <input type="text" class="fcups" name="segundo_apellido" minlength="3" autocomplete="off" style="width: 300px; text-transform: capitalize;"><br>
    <b>Especialidad</b><br>
<div class="container">
    <div class="row" style="margin-left: 6%;">
            <select class="selectpicker show-menu-arrow" data-style="form-control" data-live-search="true" title="Elija la especialidad" name="especialidad">
                    <?php
                        $consulta="SELECT*FROM especialidad";
                        $ejecutar=mysqli_query($con,$consulta);
                        $i=0;

                        while($fila=mysqli_fetch_array($ejecutar)){
                            echo $especialidad=$fila['especialidad'];
                            $i++;
                    ?>
                <option value="<?php echo $especialidad; ?>"><?php echo $especialidad; ?></option>
                    <?php } ?>
            </select>
    </div>
</div> 	
<br>
        <input type="submit" value="Añadir" name="agregar" class="btn btn-success btn-primary"><br>
</form>

        </div>
        <br><br>

        <div class="modal-footer">
        	<a href="" class="btn btn-default" data-dismiss="modal">Cancelar</a>
        </div>
      </div>
    </div>
  </div>
</div>


<br>
    <hr>
      <p style="font-size: 23px;" class="text-center">Administrar doctores</p>
    <hr>

<br><br>
<!--Boton agregar médico-->
<a href="#agregar" class="btn btn-info btn-lg" data-toggle="modal" style="float: right;">Agregar doctor</a>


<!--Guardar médico-->
<?php
if(isset($_POST['agregar'])){
	$cedula2=$_POST['cedula'];
	$primer_nombre2=$_POST['primer_nombre'];
	$segundo_nombre2=$_POST['segundo_nombre'];
	$primer_apellido2=$_POST['primer_apellido'];
	$segundo_apellido2=$_POST['segundo_apellido'];
	$especialidad2=$_POST['especialidad'];
	$nombre=$_POST['primer_nombre'].' '.$_POST['primer_apellido'];

	$insertar="INSERT INTO medico (cedula,primer_nombre,segundo_nombre,primer_apellido,segundo_apellido,especialidad,nombre)VALUES('$cedula2',	'$primer_nombre2','$segundo_nombre2','$primer_apellido2','$segundo_apellido2','$especialidad2','$nombre')";
	$ejecutar=mysqli_query($con,$insertar);

	$sql2="SELECT*FROM medico WHERE cedula='$cedula2'";
	$result2=mysqli_query($con,$sql2);
	$contar=mysqli_num_rows($result2);

	if($ejecutar){
        ?>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script type="text/javascript">
	    swal("Acción exitosa", " ", "success").then(function() {
	    window.location = "admin.php"; });
    </script>
        <?php
	}
	else if($contar==1){
        ?>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<script type="text/javascript">
		sweetAlert ( "El doctor ya existe"," ","error" );
	</script>
        <?php
	}
}
?>
	<form>
		<fieldset>
				<input class="p" type="text" placeholder="Cédula del doctor" id="inputBusqueda" autocomplete="off" >
				<button type="submit" class="p">
					<i class="fa fa-search" aria-hidden="true"></i>
				</button>
		</fieldset>
	</form>

	<header>
		<div class="search" id="search">
			<table class="search-table" id="searchTable">
				<thead>
					<tr>
						<td></td>
					</tr>
				</thead>
				<tbody>
					<tr>	
						<td>
							<?php
							//Busqueda 
								$consulta="SELECT*FROM medico";
								$ejecutar=mysqli_query($con,$consulta);
								$i=0;
									
								while($fila=mysqli_fetch_array($ejecutar)){
									
			                        $cedula=$fila['cedula'];

									?><a style="color: black; text-decoration: none; text-transform: capitalize;" href="doctor.php?admin_doctor=<?php echo $cedula;?>"><?php 
									echo $cedula=$fila['cedula'];

									$i++; 
							?>									
						</td>
					</tr>	
						<td><?php } ?></td>
				
				</tbody>
			</table>
		</div>
</header>


<?php
  if(isset($_GET['admin_doctor'])){
    include("admin_doctor.php");
  }
?>

<?php
  if(isset($_GET['editar_doctor'])){
    include("editar_doctor.php");
  }
?>


<!--Eliminar medico-->
<?php
  if(isset($_GET['borrar'])){
    $borrar_doctor=$_GET['borrar'];

    $borrar="DELETE FROM medico WHERE cedula='$borrar_doctor'";
    $ejecutar=mysqli_query($con,$borrar);

    if($ejecutar){
      ?>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<script type="text/javascript">
		swal("Acción exitosa", " ", "success").then(function(){window.location = "admin.php";});
	</script>
      <?php
    }
  }
?>

<!--Links de codigo para la busqueda-->
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js'></script>
<script src="buscador2.js"></script>

<!--Bloquear F12-->
<script type="text/javascript">
	$(document).keydown(function (event) {
    if (event.keyCode == 123) {
        return false;
    } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) {   
        return false;
    }
});
	$(document).on("contextmenu", function (e) {        
    e.preventDefault();
});
</script>

<!--Tiempo de inactividad cierre de sesion-->
<div id="indicator" class="activ"></div>
<script type="text/javascript">
	var indicator = document.getElementById('indicator');
var sleepTimer;

document.addEventListener('mousemove', activityDetected);
document.addEventListener('keypress', activityDetected);

function setSleepTimer() {
  sleepTimer = setTimeout(dozeOff, 900000);//tiempo de inactividad para bloqueo 15 minutos
}

function resetSleepTimer() {
  clearTimeout(sleepTimer);
  setSleepTimer();
}

function activityDetected() {
  resetSleepTimer();
  wakeUp();
}

function dozeOff() {
	location.href="../index.php";
}

setSleepTimer();
</script>

<p style="position:fixed; bottom:0px;">© 2020<label class="senseis">Omar Reyes y Johan Alvarado</label></p>

<style type="text/css">
	.senseis{
		color: transparent;
	}
	.senseis::selection{
		background-color: transparent;
	}
	.senseis:hover {
		transition: 6s;
		color: black;
	}
</style>

</body>
</html>
