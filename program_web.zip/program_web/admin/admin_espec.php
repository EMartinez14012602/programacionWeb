<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <!--Diseño modal de datos actualizados-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="../../modal/css/reset.css"> 
    <link rel="stylesheet" href="../../modal/css/modal2.css"> 
    <script src="../../modal/js/modernizr.js"></script> 
  <!--Diseño buscador-->
      <link rel="stylesheet" href="../css/style.css">
</head>

<body  style="background-color: rgb(243, 254, 244);">

<?php
  $con=mysqli_connect("localhost","root","","bd_asmedan")or die("error");
?>

<!--Tabla-->
<div class="container">
  <br><br><br>

          <table class="table table-bordered myTable" style="text-align: center;">
            <tr class="text-center">
              <th style="text-align: center; font-weight: bold;">Especialidad</th>
              <th style="text-align: center; font-weight: bold;" colspan="2">Acciones</th>
            </tr>
              <!--Editar doctor-->
              <?php
              if(isset($_GET['admin_espec'])){
                  $editar_espec=$_GET['admin_espec'];

                  $consulta="SELECT*FROM especialidad WHERE especialidad='$editar_espec'";
                  $ejecutar=mysqli_query($con,$consulta);

                  $fila=mysqli_fetch_array($ejecutar);

                  $especialidad=$fila['especialidad'];
                }
              ?>
            <tr>
              <td style="text-transform: capitalize;"><?php echo $especialidad; ?></td>
              <td>
                <a href="espec.php?editar_espec=<?php echo $especialidad; ?>" class="btn btn-warning" data-toggle="modal" name="beditar">Editar</a>
              </td>
              <td>
                <a href="#eliminar?<?php echo $especialidad; ?>" class="btn btn-danger" data-toggle="modal" ng-click="selectUser(user)" data-target="#eliminar" name="borrar">Eliminar</a>
              </td>
            </tr> 
          </table>
        </div>
      </div>
    </div>


<?php
  if(isset($_GET['editar_espec'])){
    include("editar_espec.php");
  }
?>

<?php
  if(isset($_GET['editar_espec'])){
    $editar_espec=$_GET['editar_espec'];

    $consulta="SELECT*FROM especialidad WHERE especialidad='$editar_espec'";
    $ejecutar=mysqli_query($con,$consulta);

    $fila=mysqli_fetch_array($ejecutar);

    $especialidad=$fila['especialidad'];
  }
?>
        
<!-- Modal Eliminar-->
  <div class="modal fade" id="eliminar" role="dialog">
    <div class="modal-dialog">
<!-- Modal Eliminar-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <label style="font-size: 22px;">Eliminar</label>
        </div>
        <div class="modal-body">
<br>
<!--Eliminar especialidad-->
      <label style="font-size: 22px;">¿Está seguro de eliminar la especialidad <strong style="color: red; font-weight: bold;"><?php echo $especialidad; ?></strong> ?</label>
        </div>
        <br>
        <div class="modal-footer">
          <a href="" class="btn btn-default" data-dismiss="modal">Cancelar</a>
          <a href="espec.php?borrar=<?php echo $especialidad; ?>"><input class="btn btn-danger" data-toggle="modal" ng-click="selectUser(user)" type="submit" name="borrar" value="Eliminar"></a>
        </div>
      </div>
    </div>
  </div>
</div>


<br><br><br>

<script src='https://code.jquery.com/jquery-2.2.4.min.js'></script>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.5.5/angular.min.js'></script>
  
<!--<script  src="modal.js"></script>
<script  src="index.js"></script>-->


</body>
</html>
