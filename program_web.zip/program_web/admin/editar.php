<?php
  $con=mysqli_connect("localhost","id16807202_root","C{gEr$iKKh+9K-B4","id16807202_tejedores")or die("error");
?>
<!--Editar paciente-->
<?php
if(isset($_GET['editar'])){
    $editar_usuario=$_GET['editar'];

    $consulta="SELECT*FROM usuarios WHERE usuario='$editar_usuario'";
    $ejecutar=mysqli_query($con,$consulta);

    $fila=mysqli_fetch_array($ejecutar);

    $usuario=$fila['usuario'];
    $password=$fila['password'];
    $nombre_uno=$fila['nombre_uno'];
    $nombre_dos=$fila['nombre_dos'];
    $apellido_uno=$fila['apellido_uno'];
    $apellido_dos=$fila['apellido_dos'];
    $ciudad=$fila['ciudad'];
    $rol=$fila['rol'];
}
?>

<!--Actualizar datos usuario-->
<?php
  if(isset($_POST['actualizar'])){
    $actualizar_usuario=$_POST['usuario'];
    $actualizar_password=$_POST['password'];
    $actualizar_nombre_uno=$_POST['nombre_uno'];
    $actualizar_nombre_dos=$_POST['nombre_dos'];
    $actualizar_apellido_uno=$_POST['apellido_uno'];
    $actualizar_apellido_dos=$_POST['apellido_dos'];
    $actualizar_ciudad=$_POST['ciudad'];
    $actualizar_rol=$_POST['rol'];

    $actualizar="UPDATE usuarios SET usuario='$actualizar_usuario', password='$actualizar_password', nombre_uno='$actualizar_nombre_uno', nombre_dos='$actualizar_nombre_dos', apellido_uno='$actualizar_apellido_uno', apellido_dos='$actualizar_apellido_dos', ciudad='$actualizar_ciudad', rol='$actualizar_rol' WHERE usuario='$editar_usuario'";

    $ejecutar=mysqli_query($con, $actualizar);

      $sql2="SELECT*FROM usuarios WHERE usuario='$usuario'";
      $result2=mysqli_query($con,$sql2);
      $contar1=mysqli_num_rows($result2);

  if($ejecutar){
    ?>
      <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
      <script type="text/javascript">
        swal("Acción exitosa", " ", "success").then(function() {
    window.location = "admin.php";
});
      </script>
    <?php
  }
  else if($contar1==1){
    ?>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script type="text/javascript">
          sweetAlert ( "El usuario ya existe" , " " , "error" );
        </script>
    <?php
  }
}
?>

<!--Editar Usuario-->
<form method="POST" action="" style="margin-left: 10%;">
    <b>Usuario</b> 
        <input type="text" class="forml" name="usuario" required="" minlength="3" autocomplete="off" autofocus="" value="<?php echo $usuario; ?>"><br>
    <b>Contraseña</b> 
        <input type="password" class="forml" name="password" required="" minlength="4" autocomplete="off" value="<?php echo $password; ?>"><br>
    <b>Primer nombre</b> 
        <input type="text" class="forml" name="nombre_uno" required="" minlength="3" autocomplete="off" style="text-transform: capitalize;" value="<?php echo $nombre_uno; ?>"><br>
    <b>Segundo nombre</b> 
        <input type="text" class="forml" name="nombre_dos" minlength="3" autocomplete="off" style="text-transform: capitalize;" value="<?php echo $nombre_dos; ?>"><br>
    <b>Primer apellido</b> 
        <input type="text" class="forml" name="apellido_uno" required="" minlength="3" autocomplete="off" style="text-transform: capitalize;" value="<?php echo $apellido_uno; ?>"><br>
    <b>Segundo apellido</b> 
        <input type="text" class="forml" name="apellido_dos" minlength="3" autocomplete="off" style="text-transform: capitalize;" value="<?php echo $apellido_dos; ?>"><br>
    <b>Ciudad</b> 
        <input type="text" class="forml" name="ciudad" required="" minlength="4" autocomplete="off" style="text-transform: capitalize;" value="<?php echo $ciudad; ?>"><br>
    <b>Permisos</b> 
<br>
    <label>
        <input type="radio" name="rol" required="" value="administrador">Administrador
    </label>
<br>
    <label>
        <input type="radio" name="rol" value="consultas">Consultas
    </label>
<br>
    <label>
        <input type="radio" name="rol" value="usuario">Usuario<br><br>
    </label>
<br>


    <input type="submit" value="Editar" name="actualizar" class="btn btn-success btn-primary">
    <a href="#eliminar?<?php echo $usuario; ?>" ><button type="button" class="btn btn-danger" data-toggle="modal" ng-click="selectUser(user)" data-target="#eliminar" >Eliminar</button></a>
<!--volver-->
<a href="javascript:history.go(-1);" style="background-color: #b3b3b3; border-radius: 10px; text-decoration: none; color: black; padding: 5px;">Cancelar</a>
   
</form>