<?php
  $con=mysqli_connect("localhost","root","","bd_asmedan")or die("error");
?>

<!--Editar cups-->
<?php
if(isset($_GET['editar_cups'])){
    $editar_cup=$_GET['editar_cups'];

    $consulta="SELECT*FROM cups WHERE cups='$editar_cup'";
    $ejecutar=mysqli_query($con,$consulta);

    $fila=mysqli_fetch_array($ejecutar);

    $cups=$fila['cups'];
    $descripcion=$fila['descripcion'];
}
?>

<!--Actualizar datos usuario-->
<?php
  if(isset($_POST['actualizar'])){
    $actualizar_cups=$_POST['cups'];
    $actualizar_descripcion=$_POST['descripcion'];

    $actualizar="UPDATE cups SET cups='$actualizar_cups', descripcion='$actualizar_descripcion' WHERE cups='$editar_cup'";

    $ejecutar=mysqli_query($con, $actualizar);

      $sql2="SELECT*FROM cups WHERE cups='$cups'";
      $result2=mysqli_query($con,$sql2);
      $contar1=mysqli_num_rows($result2);

  if($ejecutar){
    ?>
      <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
      <script type="text/javascript">
        swal("Acción exitosa", " ", "success").then(function() {
    window.location = "admin.php";
});
      </script>
    <?php
  }
  else if($contar1==1){
    ?>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script type="text/javascript">
          sweetAlert ( "El cup ya existe" , " " , "error" );
        </script>
    <?php
  }
}
?>

<!--Editar cups-->
<form method="POST" action="" >

<br><br><br>
    <b>Número de cup</b>
	<input name="cups" class="feditar" type="text" value="<?php echo $cups; ?>" required="required" minlength="5" autocomplete="off"/>
	<br><br><br>

	<b>Descripción</b>
	<input name="descripcion" class="feditar" type="text" value="<?php echo $descripcion; ?>" required="required" minlength="5" autocomplete="off"><br><br>
<br><br><br>

	<input type="submit" value="Editar" name="actualizar" class="btn btn-success btn-primary">
	<br>
<!--volver-->
<a href="javascript:history.go(-1);" style="background-color: #b3b3b3; border-radius: 10px; text-decoration: none; color: black; padding: 5px;">Cancelar</a>

</form>

<br><br><br><br>