<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="utf-8">
</head>

<body  style="background-color: rgb(243, 254, 244);">

<?php
  $con=mysqli_connect("localhost","root","","bd_asmedan")or die("error");
?>

<!--Tabla-->
<div class="container">
  <br><br><br>

          <table class="table table-bordered myTable" style="text-align: center;">
            <tr class="text-center">
              <th style="text-align: center; font-weight: bold;">Cédula</th>
              <th style="text-align: center; font-weight: bold;">Nombre</th>
              <th style="text-align: center; font-weight: bold;">Editar</th>
            </tr>
              <!--Editar paciente-->
              <?php
              if(isset($_GET['ad_paci'])){
                  $editar_numero=$_GET['ad_paci'];

                  $consulta="SELECT*FROM paciente WHERE numero='$editar_numero'";
                  $ejecutar=mysqli_query($con,$consulta);

                  $fila=mysqli_fetch_array($ejecutar);

                  $numero=$fila['numero'];
                  $nombre=$fila['nombre'];
                }
              ?>
            <tr>
              <td><?php echo $numero; ?></td>
              <td style="text-transform: capitalize;"><?php echo $nombre; ?></td>
              <td>
                <a href="paci.php?editar_paciente=<?php echo $numero; ?>" class="btn btn-warning" data-toggle="modal" name="beditar">Editar</a>
              </td>
            </tr>
              
          </table>

        </div>
      </div>
    </div>


<?php
  if(isset($_GET['editar_paciente'])){
    include("editar_paciente.php");
  }
?>

<?php
  if(isset($_GET['editar_paciente'])){
    $editar_usuario=$_GET['editar_paciente'];

    $consulta="SELECT*FROM paciente WHERE usuario='$editar_usuario'";
    $ejecutar=mysqli_query($con,$consulta);

    $fila=mysqli_fetch_array($ejecutar);

    $numero=$fila['numero'];
    $nombre=$fila['nombre'];
  }
?>
    
<script src='https://code.jquery.com/jquery-2.2.4.min.js'></script>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.5.5/angular.min.js'></script>

</body>
</html>
