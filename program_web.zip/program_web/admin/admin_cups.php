<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <!--Diseño modal de datos actualizados-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="../../modal/css/reset.css"> 
    <link rel="stylesheet" href="../../modal/css/modal2.css"> 
    <script src="../../modal/js/modernizr.js"></script> 
  <!--Diseño buscador-->
      <link rel="stylesheet" href="../css/style.css">
</head>

<body  style="background-color: rgb(243, 254, 244);">

<?php
  $con=mysqli_connect("localhost","root","","bd_asmedan")or die("error");

?>

<!--Tabla-->
<div class="container">
  <br><br><br>

          <table class="table table-bordered myTable" style="text-align: center;">
            <tr class="text-center">
              <th style="text-align: center; font-weight: bold;">Número</th>
              <th style="text-align: center; font-weight: bold;">Descripción</th>
              <th style="text-align: center; font-weight: bold;" colspan="2">Acciones</th>
            </tr>
              <!--Editar paciente-->
              <?php
              if(isset($_GET['admin_cups'])){
                  $editar_cups=$_GET['admin_cups'];

                  $consulta="SELECT*FROM cups WHERE cups='$editar_cups'";
                  $ejecutar=mysqli_query($con,$consulta);

                  $fila=mysqli_fetch_array($ejecutar);

                  $cups=$fila['cups'];
                  $descripcion=$fila['descripcion'];
                }
              ?>
            <tr>
              <td><?php echo $cups; ?></td>
              <td><?php echo $descripcion; ?></td>
              <td>
                <a href="cups.php?editar_cups=<?php echo $cups; ?>" class="btn btn-warning" data-toggle="modal" name="beditar">Editar</a>
              </td>
              <td>
                <a href="#eliminar?<?php echo $cups; ?>" class="btn btn-danger" data-toggle="modal" ng-click="selectUser(user)" data-target="#eliminar" name="borrar">Eliminar</a>
              </td>
            </tr> 
          </table>
        </div>
      </div>
    </div>


<?php
  if(isset($_GET['editar_cups'])){
    include("editar_cups.php");
  }
?>

<?php
  if(isset($_GET['editar_cups'])){
    $editar_cup=$_GET['editar_cups'];

    $consulta="SELECT*FROM cups WHERE usuario='$editar_cup'";
    $ejecutar=mysqli_query($con,$consulta);

    $fila=mysqli_fetch_array($ejecutar);

    $cups=$fila['cups'];
    $descripcion=$fila['descripcion'];
  }
?>
        
<!-- Modal Eliminar-->
  <div class="modal fade" id="eliminar" role="dialog">
    <div class="modal-dialog">
<!-- Modal Eliminar-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <label style="font-size: 22px;">Eliminar</label>
        </div>
        <div class="modal-body">
<br>
<!--Eliminar cup-->
      <label style="font-size: 22px;">¿Está seguro de eliminar el cup <strong style="color: red; font-weight: bold;"><?php echo $cups; ?></strong> ?</label>
        </div>
        <br>
        <div class="modal-footer">
          <a href="" class="btn btn-default" data-dismiss="modal">Cancelar</a>
          <a href="cups.php?borrar=<?php echo $cups; ?>"><input class="btn btn-danger" data-toggle="modal" ng-click="selectUser(user)" type="submit" name="borrar" value="Eliminar"></a>
        </div>
      </div>
    </div>
  </div>
</div>


<br><br><br>

<script src='https://code.jquery.com/jquery-2.2.4.min.js'></script>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.5.5/angular.min.js'></script>
  
<!--<script  src="modal.js"></script>
<script  src="index.js"></script>-->


</body>
</html>
