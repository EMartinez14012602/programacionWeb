/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 * @module highcharts/themes/sand-signika
 * @requires highcharts
 *
 * (c) 2009-2019 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../themes/sand-signika.js';
