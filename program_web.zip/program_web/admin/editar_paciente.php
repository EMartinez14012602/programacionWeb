<?php
  $con=mysqli_connect("localhost","root","","bd_asmedan")or die("error");
?>

<!--Editar paciente-->
<?php
if(isset($_GET['editar_paciente'])){
    $editar_numero=$_GET['editar_paciente'];

    $consulta="SELECT*FROM paciente WHERE numero='$editar_numero'";
    $ejecutar=mysqli_query($con,$consulta);

    $fila=mysqli_fetch_array($ejecutar);

    $numero=$fila['numero'];
    $nombre=$fila['nombre'];
}
?>

<!--Actualizar datos usuario-->
<?php
  if(isset($_POST['actualizar'])){
    $actualizar_numero=$_POST['numero'];
    $actualizar_nombre=$_POST['nombre'];

    $actualizar="UPDATE paciente SET numero='$actualizar_numero', nombre='$actualizar_nombre' WHERE numero='$editar_numero'";

    $ejecutar=mysqli_query($con, $actualizar);

      $sql2="SELECT*FROM paciente WHERE numero='$numero'";
      $result2=mysqli_query($con,$sql2);
      $contar1=mysqli_num_rows($result2);

  if($ejecutar){
    ?>
      <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
      <script type="text/javascript">
        swal("Acción exitosa", " ", "success").then(function() {
    window.location = "admin.php";
});
      </script>
    <?php
  }
  else if($contar1==1){
    ?>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script type="text/javascript">
          sweetAlert ( "El paciente ya existe" , " " , "error" );
        </script>
    <?php
  }
}
?>

<!--Editar paciente-->
<form method="POST" action="" >

<br><br><br>

	<p class="neditar">Identificación</p>
	<input name="numero" class="feditar" type="text" value="<?php echo $numero; ?>" required="required" minlength="5" autocomplete="off"/>
	<br><br>

	<p class="neditar">Nombres y Apellidos</p>
	<input name="nombre" class="feditar" type="text" value="<?php echo $nombre; ?>" required="required" minlength="5" autocomplete="off" style="text-transform: capitalize;"/><br><br><br>

	<input type="submit" value="Editar" name="actualizar" class="btn btn-success btn-primary">

<!--Volver-->
<a href="javascript:history.go(-1);" style="background-color: #b3b3b3; border-radius: 10px;">Cancelar</a>

	<br><br>

</form>
<br><br><br><br>