<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Administrador</title>
  <!--Funcionamiento reloj-->
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <script  src="../hora/tiempo.js"></script>
    <link rel="stylesheet" href="../css/style2.css">
  <!--Diseño header-->
    <link rel="stylesheet" type="text/css" href="../css/dess.css">
  <!--Icono de cerrar sesion-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!--Diseño menu-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <link rel="stylesheet" href="css/mee.css">
  <!-- CSS Bootstrap -->
      <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
      <link href="../css/full-slider.css" rel="stylesheet">
  <!--Diseño tarjetas-->
      <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Nunito+Sans:300,400,700'>
      <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Poppins:300,400,700'>
      <link rel="stylesheet" type="text/css" href="../css/style.css">    



</head>


<?php
  $con=mysqli_connect("localhost","root","","tejedores")or die("error");
  session_start();

	if (@!$_SESSION['usuario']) {
		header("Location: ../index.php");
	}
?>
 <body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
  <div class="container">
    <a class="navbar-brand" href="#">Tienda</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item active">
          <a class="nav-link" href="#">Inicio
            <span class="sr-only">(current)</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Tejedor</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Opción 1</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="index.php">Cerrar Sesion</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<!-- Page Content -->
<section class="py-5">
  <div class="container">
    <br>
    <h1 align="center">Venta de productos</h1><br>



    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <hr/>
            <p style="font-size: 23px;" class="text-center">Administrar usuarios</p>
          <hr/>
        </div>
      </div>
    </div>

<!--Guardar usuario-->
<?php
if(isset($_POST['agregar'])){
  $usuario1=$_POST['usuario'];
  $password1=$_POST['password'];
  $nombre_uno1=$_POST['nombre_uno'];
  $nombre_dos1=$_POST['nombre_dos'];
  $apellido_uno1=$_POST['apellido_uno'];
  $apellido_dos1=$_POST['apellido_dos'];
  $ciudad1=$_POST['ciudad'];
  $rol1=$_POST['rol'];

  $insertar="INSERT INTO usuarios (usuario,password,nombre_uno,nombre_dos,apellido_uno,apellido_dos,ciudad,rol)VALUES('$usuario1','$password1','$nombre_uno1','$nombre_dos1','$apellido_uno1', '$apellido_dos1','$ciudad1', '$rol1')";
  $ejecutar=mysqli_query($con,$insertar);

  $sql2="SELECT*FROM usuarios WHERE usuario='$usuario1'";
  $result2=mysqli_query($con,$sql2);
  $contar1=mysqli_num_rows($result2);
  
  if($ejecutar){
    ?>
      <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
      <script type="text/javascript">
        swal("Acción exitosa", " ", "success");
      </script>
    <?php
  }
  else if($contar1==1){
    ?>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script type="text/javascript">
          sweetAlert ( "El usuario ya existe" , " " , "error" );
        </script>
    <?php
  }
}
?>

<!-- Modal Agregar-->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
<!-- Modal Agregar-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h3 class="modal-title" align="center" >Agregar</h3>
        </div>
        <div class="modal-body">

<!--Agregar usuario-->
    <form method="POST" action="admin.php">
        <b>Usuario</b> 
            <input type="text" class="forml" name="usuario" required="" minlength="3" autocomplete="off" autofocus=""><br>
        <b>Contraseña</b> 
            <input type="password" class="forml" name="password" required="" minlength="4" autocomplete="off"><br>
        <b>Nombre uno</b> 
            <input type="text" class="forml" name="nombre_uno" required="" minlength="3" autocomplete="off" style="text-transform: capitalize;"><br>
        <b>Nombre dos</b> 
            <input type="text" class="forml" name="nombre_dos" minlength="3" autocomplete="off" style="text-transform: capitalize;"><br>
        <b>Apellido uno</b> 
            <input type="text" class="forml" name="apellido_uno" required="" minlength="3" autocomplete="off" style="text-transform: capitalize;"><br>
        <b>Apellido dos</b> 
            <input type="text" class="forml" name="apellido_dos" minlength="3" autocomplete="off" style="text-transform: capitalize;"><br>
        <b>Ciudad</b> 
            <input type="text" class="forml" name="ciudad" required="" minlength="4" autocomplete="off" style="text-transform: capitalize;"><br>
        <b>Permisos</b> <br>
        <label>
            <input type="radio" name="rol"  value="administrador" required="">Administrador
        </label>
        <br>
        <label>
            <input type="radio" name="rol" value="consultas">Consulta
        </label>          
        <br>
        <label>
            <input type="radio" name="rol" value="usuario">Usuario
        </label>      
        <br><br>
        <input type="submit" value="Añadir" name="agregar" class="btn btn-success btn-primary">
    </form>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
        </div>
      </div>
    </div>
  </div>
</div>

<!--Tabla-->
<div class="container">
    <div>
      <div>
  <!--Boton agregar -->
  <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" style="float: right;">Agregar usuario</button>
  <br><br><br>

          <table class="table table-bordered myTable" style="text-align: center;">
            <tr class="text-center">
              <th style="text-align: center;">Usuario</th>
              <th style="text-align: center;">Nombre</th>
              <th style="text-align: center;">ciudad</th>
              <th style="text-align: center;">Permiso</th>
              <th style="text-align: center;">Acciones</th>
            </tr>
                <?php
                    $consulta="SELECT*FROM usuarios";
                    $ejecutar=mysqli_query($con,$consulta);
                    $i=0;
                    while($fila=mysqli_fetch_array($ejecutar)){
                      $usuario=$fila['usuario'];
                      $nombre_uno=$fila['nombre_uno'];
                      $nombre_dos=$fila['nombre_dos'];
                      $apellido_uno=$fila['apellido_uno'];
                      $apellido_dos=$fila['apellido_dos'];
                      $ciudad=$fila['ciudad'];
                      $rol=$fila['rol'];
                      $i++;
                  ?>
            <tr>
              <td><?php echo $usuario; ?></td>
              <td style="text-transform: capitalize;"><?php echo $nombre_uno," ",$nombre_dos," ",$apellido_uno," ",$apellido_dos; ?></td>
              <td style="text-transform: capitalize;"><?php echo $ciudad; ?></td>
              <td style="text-transform: capitalize;"><?php echo $rol; ?></td>
              <td>
                <a href="admin.php?editar=<?php echo $usuario;?>"><input class="btn btn-warning" data-toggle="modal" type="submit" name="beditar" value="Editar o eliminar"></a>
              </td>
            </tr>
              <?php } ?>
          </table>

        </div>
      </div>
    </div>


<?php
  if(isset($_GET['editar'])){
    include("editar.php");
  }
?>

<!-- Modal Eliminar-->
  <div class="modal fade" id="eliminar" role="dialog">
    <div class="modal-dialog">
<!-- Modal Eliminar-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4>Eliminar</h4>
        </div>
        <div class="modal-body">

<!--Eliminar usuario-->
      <label style="font-size: 22px;">¿Está seguro de eliminar a <strong style="color: red;"><?php echo $usuario; ?></strong> ?</label>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
          <a href="admin.php?borrar=<?php echo $usuario; ?>"><input class="btn btn-danger" data-toggle="modal" ng-click="selectUser(user)" type="submit" name="beditar" value="Eliminar"></a>
        </div>
      </div>
    </div>
  </div>

<br><br><br>

<!--Eliminar usuario-->
<?php
  if(isset($_GET['borrar'])){
    $borrar_usuario=$_GET['borrar'];

    $borrar="DELETE FROM usuarios WHERE usuario='$borrar_usuario'";
    $ejecutar=mysqli_query($con,$borrar);

    if($ejecutar){
      ?>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script type="text/javascript">
      swal("Acción exitosa", " ", "success").then(function() {
    window.location = "admin.php";
});
    </script>
      <?php
    }
  }
?>


    <p>.
      <code>.</code>
       .</p>
  </div>
</section>

<!-- Footer -->
<footer class="py-5 bg-dark">
  <div class="container">
    <p class="m-0 text-center text-white">Copyright &copy; 2021</p>
  </div>
  <!-- /.container -->
</footer>

    <!-- JavaScript Bootstrap -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!--Bloquear F12-->
<script type="text/javascript">
  $(document).keydown(function (event) {
    if (event.keyCode == 123) {
        return false;
    } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) {     
        return false;
    }
    });
      $(document).on("contextmenu", function (e) {        
        e.preventDefault();
    });
</script>

  </body>

</html>

