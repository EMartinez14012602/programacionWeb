<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Devoluciones</title>
  <!--Funcionamiento reloj-->
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <script  src="../hora/tiempo.js"></script>
    <link rel="stylesheet" href="../css/style2.css">
  <!--Diseño header-->
    <link rel="stylesheet" type="text/css" href="../css/dess.css">
  <!--Icono de cerrar sesion-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <!--Diseño menu-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <link rel="stylesheet" href="css/mee.css">
</head>

<body ng-app="myApp" ng-controller="myController" style="background-color: rgb(243, 254, 244);">


<?php
  $con=mysqli_connect("localhost","root","","bd_asmedan")or die("error");
  session_start();

  if (@!$_SESSION['usuario']) {
    header("Location: ../");
  }
?>

<!--header-->
<div class="header">

  <!--Imagen Asmedan al principio de pantalla-->
    <a href="admin.php"><img align="right" src="../img/lg_asm.png" width="15%" height="18%" style="float: left; position: absolute;"></a>
      <!--Imprimir todo el nombre del usuario-->
    <div style="text-transform: capitalize;float: right;">
      <?php
        include("../usuario2.php");
      ?>
    </div>
<br>
  <!--Imprimir la hora y fecha-->
    <div style="float: right;">
      <?php
        include("../hora/tiempo.php");
      ?>
    </div>

<br><br><br>

<!--menu-->
<ul id="menu">

  <li>
    <a href="" class="es">Administrar médicos</a>
      <ul>
        <li>
          <a class="ull" href="espec.php">Administrar especialidad</a>
        </li>
        <li>
          <a class="ull2" href="doctor.php">Administrar doctores</a>
        </li>
      </ul>
  </li>

  <li><a href="cups.php">Administrar cups</a></li>
  <li><a href="paci.php">Administrar pacientes</a></li>
  <li><a href="consulta.php">Informe</a>

  <li>
    <a href=""><span class="glyphicon glyphicon-user"></span><?php include("../usuario3.php"); ?></a>
      <ul>
        <li>
          <a href="../cambio.php?cambio=<?php echo $_SESSION['usuario']; ?>">Cambiar contraseña</a>
        </li>
      </ul>
  </li>
  <li><a href="../"><span class="glyphicon glyphicon-log-out"> Cerrar Sesión</span></a></li>
</ul>
<!--fin menu-->

<br><br><br><br><br><br>

    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <hr/>
            <p style="font-size: 23px;" class="text-center">Devoluciones</p>
          <hr/>
        </div>
      </div>
    </div>

<!--Tabla-->
   <div class="table-responsive"  style="overflow-x: hidden;">

    <!--Excel-->
    <input type="button" class="btn btn-primary" id="btnExport" value="Exportar a Excel" style="float: right;">

    <br><br>
    <div class="row">
     <div class="input-daterange">
      <div class="col-md-4">
       <input type="text" name="start_date" id="start_date" class="form-control" placeholder="Desde la Fecha" autocomplete="off" />
      </div>
      <div class="col-md-4">
       <input type="text" name="end_date" id="end_date" class="form-control" placeholder="Hasta la Fecha" autocomplete="off" />
      </div>      
     </div>
     <div class="col-md-4">
      <input type="button" name="search" id="search" value="Buscar" class="btn btn-info active" />
     </div>
    </div>
    <br>

<!--Excel-->
<div id="excel">

    <table id="order_data" class="table  table-striped  table-hover">
     <thead>
        <tr>
            <th style="text-align: center;">N°</th>
            <th style="text-align: center;">Identificación</th>
            <th style="text-align: center;">Motivo</th>
            <th style="text-align: center;">Valor</th>
            <th style="text-align: center;">Fecha</th>
            <th style="text-align: center;">Cajero</th>                                   
        </tr>
                <?php
                    $consulta="SELECT*FROM devolucion";
                    $ejecutar=mysqli_query($con,$consulta);
                    $i=0;
                    while($fila=mysqli_fetch_array($ejecutar)){
                      $id=$fila['id'];
                      $cedula=$fila['cedula'];
                      $motivo=$fila['motivo'];
                      $valor=$fila['valor'];                                         
                      $fecha=$fila['fecha'];
                      $cajero=$fila['cajero'];                                                           
                      $i++;
                  ?>

              <?php } ?>
     </thead>
    </table>
    
    </div>
  </div>
</div>

<script>
$("#btnExport").click(function(e) {
    window.open('data:application/vnd.ms-excel,' + encodeURIComponent($('#excel').html()));
    e.preventDefault();
});
</script>
  <!--<script src="bootstrap-3.3.7/js/jQuery-2.1.4.min.js"></script>
<script src="bootstrap-3.3.7/js/bootstrap.min.js"></script>-->
  <script src="../plugins/datepicker/bootstrap-datepicker.js"></script>
    <script src="../plugins/datatables/jquery.js" type="text/javascript"></script>
    <script src="../plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>

<script type="text/javascript" language="javascript" >

$(document).ready(function(){

 $('.input-daterange').datepicker({
    "locale": {
        "separator": " - ",
        "applyLabel": "Aplicar",
        "cancelLabel": "Cancelar",
        "fromLabel": "Desde",
        "toLabel": "Hasta",
        "customRangeLabel": "Custom",
        "daysOfWeek": [
            "Do",
            "Lu",
            "Ma",
            "Mi",
            "Ju",
            "Vi",
            "Sa"
        ],
        "monthNames": [
            "Enero",
            "Febrero",
            "Marzo",
            "Abril",
            "Mayo",
            "Junio",
            "Julio",
            "Agosto",
            "Septiembre",
            "Octubre",
            "Noviembre",
            "Diciembre"
        ],
        "firstDay": 1
    },
  
  format: "dd/mm/yyyy",
  autoclose: true

 });

 fetch_data('no');

 function fetch_data(is_date_search, start_date='', end_date='')
 {
  var dataTable = $('#order_data').DataTable({

    "language":{
       "lengthMenu":"Mostrar _MENU_ registros por página.",
       "zeroRecords": "",
             "info": "",
             "infoEmpty": "",
             "infoFiltered": "",
             "search" : "Búsqueda",
             "LoadingRecords": "",
             " ": "",
             "SearchPlaceholder": "",
             "paginate": {
     "previous": "Anterior",
     "next": "Siguiente", 
     }
      },

   " " : true,
   "serverSide" : true,
   "sort": false,
   "order" : [],
   "ajax" : {
    url:"table.php",
    type:"POST",
    data:{
     is_date_search:is_date_search, start_date:start_date, end_date:end_date
    }
   }
  });
 }

 $('#search').click(function(){
  var start_date = $('#start_date').val();
  var end_date = $('#end_date').val();
  if(start_date != '' && end_date !='')
  {
   $('#order_data').DataTable().destroy();
   fetch_data('yes', start_date, end_date);
  }
 }); 
 
});
</script>

<?php
  if(isset($_GET['editar'])){
    include("editar.php");
  }
?>

<!-- Modal Eliminar-->
  <div class="modal fade" id="eliminar" role="dialog">
    <div class="modal-dialog">
<!-- Modal Eliminar-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4>Eliminar</h4>
        </div>
        <div class="modal-body">

<!--Eliminar paciente-->
      <label style="font-size: 22px;">¿Está seguro de eliminar a <strong style="color: red;"><?php echo $usuario; ?></strong> ?</label>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
          <a href="admin.php?borrar=<?php echo $usuario; ?>"><input class="btn btn-danger" data-toggle="modal" ng-click="selectUser(user)" type="submit" name="beditar" value="Eliminar"></a>
        </div>
      </div>
    </div>
  </div>

<br><br><br>

<!--Eliminar usuario-->
<?php
  if(isset($_GET['borrar'])){
    $borrar_usuario=$_GET['borrar'];

    $borrar="DELETE FROM usuarios WHERE usuario='$borrar_usuario'";
    $ejecutar=mysqli_query($con,$borrar);

    if($ejecutar){
      ?>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script type="text/javascript">
      swal("Acción exitosa", " ", "success").then(function() {
    window.location = "admin.php";
});
    </script>
      <?php
    }
  }
?>

<?php
  $user=$_SESSION['nombre_uno']." ".$_SESSION['apellido_uno'];//Nombre del usuario
  date_default_timezone_set('America/Bogota');

  $fecha2=date('d/m/Y');
  $fecha3=date('d/m/Y H:i:s');

  $consultar="SELECT SUM(valor) as valor2 FROM devolucion WHERE cajero='$user' AND fecha='$fecha2'";

  $resultado=$con->query($consultar);
  $fila=$resultado->fetch_assoc();

  $valor2=$fila['valor2'];

  $useer=$_SESSION['usuario'];
?>



<!--Bloquear F12-->
<script type="text/javascript">
  $(document).keydown(function (event) {
    if (event.keyCode == 123) {
        return false;
    } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) {     
        return false;
    }
});
  $(document).on("contextmenu", function (e) {        
    e.preventDefault();
});
</script>

<!--Tiempo de inactividad cierre de sesion-->
<div id="indicator" class="activ"></div>
<script type="text/javascript">
  var indicator = document.getElementById('indicator');
var sleepTimer;

document.addEventListener('mousemove', activityDetected);
document.addEventListener('keypress', activityDetected);

function setSleepTimer() {
  sleepTimer = setTimeout(dozeOff, 600000);//tiempo de inactividad para bloqueo 10 minutos
}

function resetSleepTimer() {
  clearTimeout(sleepTimer);
  setSleepTimer();
}

function activityDetected() {
  resetSleepTimer();
  wakeUp();
}

function dozeOff() {
  location.href="../index.php";
}

setSleepTimer();
</script>

</body>
</html>
