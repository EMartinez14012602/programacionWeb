<?php
  $con=mysqli_connect("localhost","root","","bd_asmedan")or die("error");

	session_start();
	if (@!$_SESSION['usuario']) {
		header("Location: ../");
	}
?>

<!DOCTYPE html>
<html>

<head>
	    <meta charset="UTF-8">
	    <title>Administrar cups</title>
	    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<!--Funcionamiento reloj-->
	    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
	    <script  src="../hora/tiempo.js"></script>
	    <link rel="stylesheet" href="../css/style2.css">
	<!--Diseño header-->
	    <link rel="stylesheet" type="text/css" href="../css/dess.css">
	<!--Icono de cerrar sesion-->
	    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<!--Diseño menu-->
	    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
	    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
	    <link rel="stylesheet" href="css/mee.css">
	<!--Diseño de la lupa-->
		<script src="https://use.fontawesome.com/a6d9678e21.js"></script>
	<!--Diseño buscador-->
	    <link rel="stylesheet" href="css/styles.css">
</head>

<body style="background-color: rgb(243, 254, 244);">

<!--header-->
<div class="header">

  <!--Imagen Asmedan al principio de pantalla-->
    <a href="admin.php"><img align="right" src="../img/lg_asm.png" width="14%" height="18%" style="float: left; position: absolute;"></a>
      <!--Imprimir todo el nombre del usuario-->
    <div style="text-transform: capitalize;float: right;">
      <?php
        include("../usuario2.php");
      ?>
    </div>
<br>
  <!--Imprimir la hora y fecha-->
    <div style="float: right;">
      <?php
        include("../hora/tiempo.php");
      ?>
    </div>
    
<br><br><br>

<!--menu-->
<ul id="menu">

  <li>
  	<a href="" class="es">Administrar médicos</a>
      <ul>
        <li>
        	<a class="ull" href="espec.php">Administrar especialidad</a>
        </li>
        <li>
        	<a class="ull2" href="doctor.php">Administrar doctores</a>
        </li>
      </ul>
  </li>

  <li><a href="admin.php">Administrar usuarios</a></li>
  <li><a href="paci.php">Administrar pacientes</a></li>
  <li><a href="consulta.php">Informe</a>
      <ul>
        <li>
        	<a style="margin-left: 500%;" href="devoluciones.php">Devoluciones</a>
        </li>
      </ul>
  </li>
  <li>
  	<a href=""><span class="glyphicon glyphicon-user"></span><?php include("../usuario3.php"); ?></a>
      <ul>
        <li>
        	<a href="../cambio.php?cambio=<?php echo $_SESSION['usuario']; ?>">Cambiar contraseña</a>
        </li>
      </ul>
  </li>

  <li><a href="../index.php"><span class="glyphicon glyphicon-log-out"> Cerrar Sesión</span></a></li>
</ul>
<!--fin menu-->

<br><br><br><br><br><br>

<!-- Modal Agregar-->
  <div class="modal fade" id="agregar" role="dialog">
    <div class="modal-dialog">
    
<!-- Modal Agregar-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <label class="modal-title" align="center" style="font-size: 20px; margin-left: 35%;">Agregar cup</label>
        </div>
        <div class="modal-body">

<!--Agregar cup-->
    <form method="POST" action="">
        <b>CUPS</b><br>
            <input type="text" class="fcups" name="cups2" required="" minlength="3" autocomplete="off" autofocus="" onkeypress="return pulsar(event)"><br><br><br>
        <b>Descripción</b><br>
            <input type="text" class="fcups" name="descripcion2" required="" minlength="5" autocomplete="off" style="width: 300px;"><br><br><br>
        <input type="submit" value="Añadir" name="agregar" class="btn btn-success btn-primary"><br>
    </form>

        </div>
        <br><br>

        <div class="modal-footer">
        	<a href="" class="btn btn-default" data-dismiss="modal">Cancelar</a>
        </div>
      </div>
    </div>
  </div>
</div>

<!--Bloquea espacio en los cups-->
<script type="text/javascript"> 
  function pulsar(e) { 
    tecla=(document.all) ? e.keyCode : e.which; 
    if(tecla==32) return false; 
  } 
</script> 

<br>
    <hr>
      <p style="font-size: 23px;" class="text-center">Administrar CUPS</p>
    <hr>

<br><br>
<!--Boton agregar cup-->
<a href="#agregar" class="btn btn-info btn-lg" data-toggle="modal" style="float: right;">Agregar CUPS</a>


<!--Guardar cup-->
<?php
if(isset($_POST['agregar'])){
	$cups3=$_POST['cups2'];
	$descripcion3=$_POST['descripcion2'];

	$insertar="INSERT INTO cups (cups,descripcion)VALUES('$cups3','$descripcion3')";
	$ejecutar=mysqli_query($con,$insertar);

	$sql2="SELECT*FROM cups WHERE cups='$cups3'";
	$result2=mysqli_query($con,$sql2);
	$contar=mysqli_num_rows($result2);

	if($ejecutar){
        ?>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script type="text/javascript">
      swal("Acción exitosa", " ", "success").then(function() {
    window.location = "admin.php";
});
    </script>
        <?php
	}
	else if($contar==1){
        ?>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<script type="text/javascript">
		sweetAlert ( "El cup ya existe"," ","error" );
	</script>
        <?php
	}
}
?>

	<form>
		<fieldset>
				<input class="p" type="text" placeholder="CUPS" id="inputBusqueda" autocomplete="off" >
				<button type="submit" class="p">
					<i class="fa fa-search" aria-hidden="true"></i>
				</button>
		</fieldset>
	</form>

	<header>
		<div class="search" id="search">
			<table class="search-table" id="searchTable">
				<thead >
					<tr>
						<td></td>
					</tr>
				</thead>
				<tbody>
					<tr>	
						<td>
							<?php
							//Busqueda 
								$consulta="SELECT*FROM cups";
								$ejecutar=mysqli_query($con,$consulta);
								$i=0;
									
								while($fila=mysqli_fetch_array($ejecutar)){
									$cups=$fila['cups'];

									?><a style="color: black; text-decoration: none;" href="cups.php?admin_cups=<?php echo $cups;?>"><?php 
									echo $cups=$fila['cups'];
									$i++; 
							?>									
						</td>
					</tr>	
						<td><?php } ?></td>
				
				</tbody>
			</table>
		</div>
	</header>


<?php
  if(isset($_GET['admin_cups'])){
    include("admin_cups.php");
  }
?>

<?php
  if(isset($_GET['editar_cups'])){
    include("editar_cups.php");
  }
?>



<!--Eliminar cup-->
<?php
  if(isset($_GET['borrar'])){
    $borrar_cups=$_GET['borrar'];

    $borrar="DELETE FROM cups WHERE cups='$borrar_cups'";
    $ejecutar=mysqli_query($con,$borrar);

    if($ejecutar){
      ?>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<script type="text/javascript">
		swal("Acción exitosa", " ", "success").then(function(){window.location = "admin.php";});
	</script>
      <?php
    }
  }
?>

<!--Links de codigo para la busqueda-->
<script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.2/jquery.min.js'></script>
<script src="buscador2.js"></script>

<!--Funcionamiento del modal
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>-->

<!--Bloquear F12-->
<script type="text/javascript">
	$(document).keydown(function (event) {
    if (event.keyCode == 123) { // Prevent F12
        return false;
    } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) { // Prevent Ctrl+Shift+I        
        return false;
    }
});
	$(document).on("contextmenu", function (e) {        
    e.preventDefault();
});
</script>

<!--Tiempo de inactividad cierre de sesion-->
<div id="indicator" class="activ"></div>
<script type="text/javascript">
	var indicator = document.getElementById('indicator');
var sleepTimer;

document.addEventListener('mousemove', activityDetected);
document.addEventListener('keypress', activityDetected);

function setSleepTimer() {
  sleepTimer = setTimeout(dozeOff, 600000);//tiempo de inactividad para bloqueo 10 minutos
}

function resetSleepTimer() {
  clearTimeout(sleepTimer);
  setSleepTimer();
}

function activityDetected() {
  resetSleepTimer();
  wakeUp();
}

function dozeOff() {
	location.href="../index.php";
}

setSleepTimer();
</script>

<p style="position:fixed; bottom:0px;">© 2020<label class="senseis">Omar Reyes y Johan Alvarado</label></p>

<style type="text/css">
	.senseis{
		color: transparent;
	}
	.senseis::selection{
		background-color: transparent;
	}
	.senseis:hover {
		transition: 6s;
		color: black;
	}
</style>

</body>
</html>
