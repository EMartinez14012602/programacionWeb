<?php
  $con=mysqli_connect("localhost","root","","bd_asmedan")or die("error");

/*Editar cups*/

if(isset($_GET['editar_espec'])){
    $editar_especi=$_GET['editar_espec'];

    $consulta="SELECT*FROM especialidad WHERE especialidad='$editar_especi'";
    $ejecutar=mysqli_query($con,$consulta);

    $fila=mysqli_fetch_array($ejecutar);

    $especialidad=$fila['especialidad'];
}
?>

<!--Actualizar datos usuario-->
<?php
  if(isset($_POST['actualizar'])){
    $actualizar_especialidad=$_POST['especialidad'];

    $actualizar="UPDATE especialidad SET especialidad='$actualizar_especialidad' WHERE especialidad='$editar_especi'";

    $ejecutar=mysqli_query($con, $actualizar);

      $sql2="SELECT*FROM especialidad WHERE especialidad='$especialidad'";
      $result2=mysqli_query($con,$sql2);
      $contar1=mysqli_num_rows($result2);

  if($ejecutar){
    ?>
      <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
      <script type="text/javascript">
        swal("Acción exitosa", " ", "success").then(function() {
    window.location = "admin.php";
});
      </script>
    <?php
  }
  else if($contar1==1){
    ?>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script type="text/javascript">
          sweetAlert ( "La especialidad ya existe" , " " , "error" );
        </script>
    <?php
  }
}
?>

<style type="text/css">
    body {
   overflow-x: hidden;
}
</style>

<br><br><br>

<!--Editar doctor-->
<form method="POST" action="" >

    <b>Especialidad</b>
	<input name="especialidad" class="feditar" type="text" style="text-transform: capitalize;" value="<?php echo $especialidad; ?>" required="required" minlength="5" autocomplete="off"/>
<br><br><br><br>
	<input type="submit" value="Editar" name="actualizar" class="btn btn-success btn-primary">
	<br>
<!--volver-->
<a href="javascript:history.go(-1);" style="background-color: #b3b3b3; border-radius: 10px; text-decoration: none; color: black; padding: 5px;">Cancelar</a>

</form>

<br><br><br><br>