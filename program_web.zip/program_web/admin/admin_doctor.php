<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <!--Diseño modal de datos actualizados-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="../../modal/css/reset.css"> 
    <link rel="stylesheet" href="../../modal/css/modal2.css"> 
    <script src="../../modal/js/modernizr.js"></script> 
  <!--Diseño buscador-->
      <link rel="stylesheet" href="../css/style.css">
</head>

<body  style="background-color: rgb(243, 254, 244);">

<?php
  $con=mysqli_connect("localhost","root","","bd_asmedan")or die("error");
?>

<!--Tabla-->
<div class="container">
  <br><br><br>

          <table class="table table-bordered myTable" style="text-align: center;">
            <tr class="text-center">
              <th style="text-align: center; font-weight: bold;">Cédula</th>
              <th style="text-align: center; font-weight: bold;">Profesional</th>
              <th style="text-align: center; font-weight: bold;">Especialidad</th>
              <th style="text-align: center; font-weight: bold;" colspan="2">Acciones</th>
            </tr>
              <!--Editar doctor-->
              <?php
              if(isset($_GET['admin_doctor'])){
                  $editar_medico=$_GET['admin_doctor'];

                  $consulta="SELECT*FROM medico WHERE cedula='$editar_medico'";
                  $ejecutar=mysqli_query($con,$consulta);

                  $fila=mysqli_fetch_array($ejecutar);

                  $cedula=$fila['cedula'];
                  $primer_nombre=$fila['primer_nombre'];
                  $segundo_nombre=$fila['segundo_nombre'];
                  $primer_apellido=$fila['primer_apellido'];
                  $segundo_apellido=$fila['segundo_apellido'];
                  $especialidad=$fila['especialidad'];
                }
                $doctor=$primer_nombre.' '.$segundo_nombre.' '.$primer_apellido.' '.$segundo_apellido;
              ?>
            <tr>
              <td style="text-transform: capitalize;"><?php echo $cedula; ?></td>
              <td style="text-transform: capitalize;"><?php echo $doctor; ?></td>
              <td style="text-transform: capitalize;"><?php echo $especialidad; ?></td>
              <td>
                <a href="doctor.php?editar_doctor=<?php echo $cedula; ?>" class="btn btn-warning" data-toggle="modal" name="beditar">Editar</a>
              </td>
              <td>
                <a href="#eliminar?<?php echo $cedula; ?>" class="btn btn-danger" data-toggle="modal" ng-click="selectUser(user)" data-target="#eliminar" name="borrar">Eliminar</a>
              </td>
            </tr> 
          </table>
        </div>
      </div>
    </div>


<?php
  if(isset($_GET['editar_medico'])){
    include("editar_medico.php");
  }
?>
        
<!-- Modal Eliminar-->
  <div class="modal fade" id="eliminar" role="dialog">
    <div class="modal-dialog">
<!-- Modal Eliminar-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <label style="font-size: 22px;">Eliminar</label>
        </div>
        <div class="modal-body">
<br>
<!--Eliminar doctor-->
      <label style="font-size: 22px;">¿Está seguro de eliminar el profesional <strong style="color: red; font-weight: bold;"><?php echo $primer_nombre.' '.$primer_apellido; ?></strong> ?</label>
        </div>
        <br>
        <div class="modal-footer">
          <a href="" class="btn btn-default" data-dismiss="modal">Cancelar</a>
          <a href="doctor.php?borrar=<?php echo $cedula; ?>"><input class="btn btn-danger" data-toggle="modal" ng-click="selectUser(user)" type="submit" name="borrar" value="Eliminar"></a>
        </div>
      </div>
    </div>
  </div>
</div>

<br><br><br>

<script src='https://code.jquery.com/jquery-2.2.4.min.js'></script>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.5.5/angular.min.js'></script>
  
</body>
</html>
